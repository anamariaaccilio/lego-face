r"""Los cuatro modelos de Face.zip, preparados para Python local.

Uso mínimo:
    modelos = cargar_modelos(r"C:\Users\USER\Documents\LegoParams\Face.zip")
    resultado = modelos.generar("persona.jpg", seed=42)
    Image.fromarray(resultado["rgba"]).save("lego.png")

La carga de los cuatro .pt no necesita internet. DINOv2 se carga bajo demanda:
se descarga una vez de Hugging Face, o se usa dino_local para trabajar offline.
Las arquitecturas y samplers incluidos proceden de los notebooks adjuntos.
Se usa strict=True y se comprueba el SHA del codec de máscaras.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
from contextlib import nullcontext
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from types import ModuleType
from typing import Any, Sequence
import zipfile

import numpy as np
from PIL import Image
import torch
from torch import nn
from torch.nn import functional as F

__all__ = ["VAEColor", "DiToMascara", "ModeloCargado", "ModelosCara",
           "cargar_vae1", "cargar_flow1", "cargar_vae2", "cargar_flow2", "cargar_modelos"]

def mascara_a(m,lado):return F.adaptive_avg_pool2d(m,lado)
def celdas_activas(m):return (F.adaptive_max_pool2d(m,16)>0.5).float()

class Residual(nn.Module):
    def __init__(self,cin,cout):
        super().__init__()
        self.red=nn.Sequential(nn.GroupNorm(8 if cin%8==0 else 1,cin),nn.SiLU(),nn.Conv2d(cin,cout,3,1,1),
                               nn.GroupNorm(8,cout),nn.SiLU(),nn.Conv2d(cout,cout,3,1,1))
        self.atajo=nn.Identity() if cin==cout else nn.Conv2d(cin,cout,1)
    def forward(self,x):return self.atajo(x)+self.red(x)
class Bajar(nn.Module):
    def __init__(self,c):
        super().__init__();self.red=nn.Sequential(nn.GroupNorm(8,c),nn.SiLU(),nn.Conv2d(c,c,4,2,1))
    def forward(self,x):return self.red(x)
class Subir(nn.Module):
    def __init__(self,cin,cout):
        super().__init__();self.red=nn.Sequential(nn.GroupNorm(8,cin),nn.SiLU(),nn.Conv2d(cin,4*cout,3,1,1),nn.PixelShuffle(2))
    def forward(self,x):return self.red(x)
class Encoder(nn.Module):
    def __init__(self,cz,canales,cin=4):
        super().__init__();capas=[nn.Conv2d(cin,canales[0],3,1,1)];c=canales[0]
        for cn in canales:capas.extend([Residual(c,cn),Bajar(cn)]);c=cn
        self.red=nn.Sequential(*capas,Residual(c,c),nn.GroupNorm(8,c),nn.SiLU());self.cabeza=nn.Conv2d(c,2*cz,1)
    def forward(self,x):
        mu,lv=self.cabeza(self.red(x)).chunk(2,1);return mu,lv.clamp(-10,10)
class DecoderCondicionado(nn.Module):
    def __init__(self,cz,canales,cout=3):
        super().__init__();c=canales[-1]
        self.entrada=nn.Sequential(nn.Conv2d(cz+1,c,1),nn.GroupNorm(8,c))
        self.bloques=nn.ModuleList();self.subidas=nn.ModuleList()
        for cn in reversed(canales):
            self.bloques.append(Residual(c+1,c));self.subidas.append(Subir(c,cn));c=cn
        self.final=Residual(c+1,c)
        self.salida=nn.Sequential(nn.GroupNorm(8,c),nn.SiLU(),nn.Conv2d(c,cout,3,1,1))
    def forward(self,z,m):
        h=self.entrada(torch.cat([z,mascara_a(m,16)],1))
        for b,u in zip(self.bloques,self.subidas):h=u(b(torch.cat([h,mascara_a(m,h.shape[-1]).to(h.dtype)],1)))
        return self.salida(self.final(torch.cat([h,m.to(h.dtype)],1)))
class VAEColor(nn.Module):
    kind='vae_control'
    def __init__(self,cz=8,canales=(32,64,128)):
        super().__init__();self.encoder=Encoder(cz,canales);self.decoder=DecoderCondicionado(cz,canales)
    def encode(self,rgb,m):return self.encoder(torch.cat([rgb,m],1))[0]*celdas_activas(m)
    def decodificar(self,z,m):return torch.sigmoid(self.decoder(z*celdas_activas(m),m))*m
    def forward(self,rgb,m):
        mu,lv=self.encoder(torch.cat([rgb,m],1))
        z=mu+torch.exp(0.5*lv)*torch.randn_like(mu) if self.training else mu
        return self.decodificar(z,m),mu,lv
    @torch.no_grad()
    def decode(self,z,m,seeds=None,steps=None):return self.decodificar(z,m)
    @torch.no_grad()
    def reconstruct(self,rgb,m,seeds=None,steps=None):return self.decode(self.encode(rgb,m),m,seeds,steps)



# Fuentes upstream y DiT preservadas de los notebooks; módulos privados para evitar
# colisiones entre las clases Encoder/Downsample de las dos arquitecturas.
_DITO_LICENSE = r'''                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
'''

_DITO_ENCODER_SOURCE = r'''# pytorch_diffusion + derived encoder decoder
import math
import torch
import torch.nn as nn
import numpy as np
from einops import rearrange

from upstream_registry import register


class LinearAttention(nn.Module):
    def __init__(self, dim, heads=4, dim_head=32):
        super().__init__()
        self.heads = heads
        hidden_dim = dim_head * heads
        self.to_qkv = nn.Conv2d(dim, hidden_dim * 3, 1, bias = False)
        self.to_out = nn.Conv2d(hidden_dim, dim, 1)

    def forward(self, x):
        b, c, h, w = x.shape
        qkv = self.to_qkv(x)
        q, k, v = rearrange(qkv, 'b (qkv heads c) h w -> qkv b heads c (h w)', heads = self.heads, qkv=3)
        k = k.softmax(dim=-1)
        context = torch.einsum('bhdn,bhen->bhde', k, v)
        out = torch.einsum('bhde,bhdn->bhen', context, q)
        out = rearrange(out, 'b heads c (h w) -> b (heads c) h w', heads=self.heads, h=h, w=w)
        return self.to_out(out)


def get_timestep_embedding(timesteps, embedding_dim):
    """
    This matches the implementation in Denoising Diffusion Probabilistic Models:
    From Fairseq.
    Build sinusoidal embeddings.
    This matches the implementation in tensor2tensor, but differs slightly
    from the description in Section 3.5 of "Attention Is All You Need".
    """
    assert len(timesteps.shape) == 1

    half_dim = embedding_dim // 2
    emb = math.log(10000) / (half_dim - 1)
    emb = torch.exp(torch.arange(half_dim, dtype=torch.float32) * -emb)
    emb = emb.to(device=timesteps.device)
    emb = timesteps.float()[:, None] * emb[None, :]
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)
    if embedding_dim % 2 == 1:  # zero pad
        emb = torch.nn.functional.pad(emb, (0,1,0,0))
    return emb


def nonlinearity(x):
    # swish
    return x*torch.sigmoid(x)


def Normalize(in_channels, num_groups=32):
    return torch.nn.GroupNorm(num_groups=num_groups, num_channels=in_channels, eps=1e-6, affine=True)


class Upsample(nn.Module):
    def __init__(self, in_channels, with_conv):
        super().__init__()
        self.with_conv = with_conv
        if self.with_conv:
            self.conv = torch.nn.Conv2d(in_channels,
                                        in_channels,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)

    def forward(self, x):
        x = torch.nn.functional.interpolate(x, scale_factor=2.0, mode="nearest")
        if self.with_conv:
            x = self.conv(x)
        return x


class Downsample(nn.Module):
    def __init__(self, in_channels, with_conv):
        super().__init__()
        self.with_conv = with_conv
        if self.with_conv:
            # no asymmetric padding in torch conv, must do it ourselves
            self.conv = torch.nn.Conv2d(in_channels,
                                        in_channels,
                                        kernel_size=3,
                                        stride=2,
                                        padding=0)

    def forward(self, x):
        if self.with_conv:
            pad = (0,1,0,1)
            x = torch.nn.functional.pad(x, pad, mode="constant", value=0)
            x = self.conv(x)
        else:
            x = torch.nn.functional.avg_pool2d(x, kernel_size=2, stride=2)
        return x


class ResnetBlock(nn.Module):
    def __init__(self, *, in_channels, out_channels=None, kernel_size=3, conv_shortcut=False,
                 dropout, temb_channels=512, normalize=True):
        super().__init__()
        self.in_channels = in_channels
        out_channels = in_channels if out_channels is None else out_channels
        self.out_channels = out_channels
        self.use_conv_shortcut = conv_shortcut

        self.norm1 = Normalize(in_channels) if normalize else torch.nn.Identity()
        self.conv1 = torch.nn.Conv2d(in_channels,
                                     out_channels,
                                     kernel_size=kernel_size,
                                     stride=1,
                                     padding=(kernel_size - 1) // 2)
        if temb_channels > 0:
            self.temb_proj = torch.nn.Linear(temb_channels,
                                             out_channels)
        self.norm2 = Normalize(out_channels) if normalize else torch.nn.Identity()
        self.dropout = torch.nn.Dropout(dropout)
        self.conv2 = torch.nn.Conv2d(out_channels,
                                     out_channels,
                                     kernel_size=kernel_size,
                                     stride=1,
                                     padding=(kernel_size - 1) // 2)
        if self.in_channels != self.out_channels:
            if self.use_conv_shortcut:
                self.conv_shortcut = torch.nn.Conv2d(in_channels,
                                                     out_channels,
                                                     kernel_size=kernel_size,
                                                     stride=1,
                                                     padding=(kernel_size - 1) // 2)
            else:
                self.nin_shortcut = torch.nn.Conv2d(in_channels,
                                                    out_channels,
                                                    kernel_size=1,
                                                    stride=1,
                                                    padding=0)

    def forward(self, x, temb):
        h = x
        h = self.norm1(h)
        h = nonlinearity(h)
        h = self.conv1(h)

        if temb is not None:
            h = h + self.temb_proj(nonlinearity(temb))[:,:,None,None]

        h = self.norm2(h)
        h = nonlinearity(h)
        h = self.dropout(h)
        h = self.conv2(h)

        if self.in_channels != self.out_channels:
            if self.use_conv_shortcut:
                x = self.conv_shortcut(x)
            else:
                x = self.nin_shortcut(x)

        return x+h


class LinAttnBlock(LinearAttention):
    """to match AttnBlock usage"""
    def __init__(self, in_channels):
        super().__init__(dim=in_channels, heads=1, dim_head=in_channels)


class AttnBlock(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels

        self.norm = Normalize(in_channels)
        self.q = torch.nn.Conv2d(in_channels,
                                 in_channels,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0)
        self.k = torch.nn.Conv2d(in_channels,
                                 in_channels,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0)
        self.v = torch.nn.Conv2d(in_channels,
                                 in_channels,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0)
        self.proj_out = torch.nn.Conv2d(in_channels,
                                        in_channels,
                                        kernel_size=1,
                                        stride=1,
                                        padding=0)


    def forward(self, x):
        h_ = x
        h_ = self.norm(h_)
        q = self.q(h_)
        k = self.k(h_)
        v = self.v(h_)

        # compute attention
        b,c,h,w = q.shape
        q = q.reshape(b,c,h*w)
        q = q.permute(0,2,1)   # b,hw,c
        k = k.reshape(b,c,h*w) # b,c,hw
        w_ = torch.bmm(q,k)     # b,hw,hw    w[b,i,j]=sum_c q[b,i,c]k[b,c,j]
        w_ = w_ * (int(c)**(-0.5))
        w_ = torch.nn.functional.softmax(w_, dim=2)

        # attend to values
        v = v.reshape(b,c,h*w)
        w_ = w_.permute(0,2,1)   # b,hw,hw (first hw of k, second of q)
        h_ = torch.bmm(v,w_)     # b, c,hw (hw of q) h_[b,c,j] = sum_i v[b,c,i] w_[b,i,j]
        h_ = h_.reshape(b,c,h,w)

        h_ = self.proj_out(h_)

        return x+h_


def make_attn(in_channels, attn_type="vanilla"):
    assert attn_type in ["vanilla", "linear", "none"], f'attn_type {attn_type} unknown'
    # print(f"making attention of type '{attn_type}' with {in_channels} in_channels")
    if attn_type == "vanilla":
        return AttnBlock(in_channels)
    elif attn_type == "none":
        return nn.Identity(in_channels)
    else:
        return LinAttnBlock(in_channels)


class Model(nn.Module):
    def __init__(self, *, ch, out_ch, ch_mult=(1,2,4,8), num_res_blocks,
                 attn_resolutions, dropout=0.0, resamp_with_conv=True, in_channels,
                 resolution, use_timestep=True, use_linear_attn=False, attn_type="vanilla"):
        super().__init__()
        if use_linear_attn: attn_type = "linear"
        self.ch = ch
        self.temb_ch = self.ch*4
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        self.resolution = resolution
        self.in_channels = in_channels

        self.use_timestep = use_timestep
        if self.use_timestep:
            # timestep embedding
            self.temb = nn.Module()
            self.temb.dense = nn.ModuleList([
                torch.nn.Linear(self.ch,
                                self.temb_ch),
                torch.nn.Linear(self.temb_ch,
                                self.temb_ch),
            ])

        # downsampling
        self.conv_in = torch.nn.Conv2d(in_channels,
                                       self.ch,
                                       kernel_size=3,
                                       stride=1,
                                       padding=1)

        curr_res = resolution
        in_ch_mult = (1,)+tuple(ch_mult)
        self.down = nn.ModuleList()
        for i_level in range(self.num_resolutions):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_in = ch*in_ch_mult[i_level]
            block_out = ch*ch_mult[i_level]
            for i_block in range(self.num_res_blocks):
                block.append(ResnetBlock(in_channels=block_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            down = nn.Module()
            down.block = block
            down.attn = attn
            if i_level != self.num_resolutions-1:
                down.downsample = Downsample(block_in, resamp_with_conv)
                curr_res = curr_res // 2
            self.down.append(down)

        # middle
        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)
        self.mid.attn_1 = make_attn(block_in, attn_type=attn_type)
        self.mid.block_2 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)

        # upsampling
        self.up = nn.ModuleList()
        for i_level in reversed(range(self.num_resolutions)):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_out = ch*ch_mult[i_level]
            skip_in = ch*ch_mult[i_level]
            for i_block in range(self.num_res_blocks+1):
                if i_block == self.num_res_blocks:
                    skip_in = ch*in_ch_mult[i_level]
                block.append(ResnetBlock(in_channels=block_in+skip_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            up = nn.Module()
            up.block = block
            up.attn = attn
            if i_level != 0:
                up.upsample = Upsample(block_in, resamp_with_conv)
                curr_res = curr_res * 2
            self.up.insert(0, up) # prepend to get consistent order

        # end
        self.norm_out = Normalize(block_in)
        self.conv_out = torch.nn.Conv2d(block_in,
                                        out_ch,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)

    def forward(self, x, t=None, context=None):
        #assert x.shape[2] == x.shape[3] == self.resolution
        if context is not None:
            # assume aligned context, cat along channel axis
            x = torch.cat((x, context), dim=1)
        if self.use_timestep:
            # timestep embedding
            assert t is not None
            temb = get_timestep_embedding(t, self.ch)
            temb = self.temb.dense[0](temb)
            temb = nonlinearity(temb)
            temb = self.temb.dense[1](temb)
        else:
            temb = None

        # downsampling
        hs = [self.conv_in(x)]
        for i_level in range(self.num_resolutions):
            for i_block in range(self.num_res_blocks):
                h = self.down[i_level].block[i_block](hs[-1], temb)
                if len(self.down[i_level].attn) > 0:
                    h = self.down[i_level].attn[i_block](h)
                hs.append(h)
            if i_level != self.num_resolutions-1:
                hs.append(self.down[i_level].downsample(hs[-1]))

        # middle
        h = hs[-1]
        h = self.mid.block_1(h, temb)
        h = self.mid.attn_1(h)
        h = self.mid.block_2(h, temb)

        # upsampling
        for i_level in reversed(range(self.num_resolutions)):
            for i_block in range(self.num_res_blocks+1):
                h = self.up[i_level].block[i_block](
                    torch.cat([h, hs.pop()], dim=1), temb)
                if len(self.up[i_level].attn) > 0:
                    h = self.up[i_level].attn[i_block](h)
            if i_level != 0:
                h = self.up[i_level].upsample(h)

        # end
        h = self.norm_out(h)
        h = nonlinearity(h)
        h = self.conv_out(h)
        return h

    def get_last_layer(self):
        return self.conv_out.weight


class Encoder(nn.Module):
    def __init__(self, *, ch, out_ch, ch_mult=(1,2,4,8), num_res_blocks,
                 attn_resolutions, dropout=0.0, resamp_with_conv=True, in_channels,
                 resolution, z_channels, double_z=True, use_linear_attn=False, attn_type="vanilla",
                 **ignore_kwargs):
        super().__init__()
        if use_linear_attn: attn_type = "linear"
        self.ch = ch
        self.temb_ch = 0
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        self.resolution = resolution
        self.in_channels = in_channels

        # downsampling
        self.conv_in = torch.nn.Conv2d(in_channels,
                                       self.ch,
                                       kernel_size=3,
                                       stride=1,
                                       padding=1)

        curr_res = resolution
        in_ch_mult = (1,)+tuple(ch_mult)
        self.in_ch_mult = in_ch_mult
        self.down = nn.ModuleList()
        for i_level in range(self.num_resolutions):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_in = ch*in_ch_mult[i_level]
            block_out = ch*ch_mult[i_level]
            for i_block in range(self.num_res_blocks):
                block.append(ResnetBlock(in_channels=block_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            down = nn.Module()
            down.block = block
            down.attn = attn
            if i_level != self.num_resolutions-1:
                down.downsample = Downsample(block_in, resamp_with_conv)
                curr_res = curr_res // 2
            self.down.append(down)

        # middle
        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)
        self.mid.attn_1 = make_attn(block_in, attn_type=attn_type)
        self.mid.block_2 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)

        # end
        self.norm_out = Normalize(block_in)
        self.conv_out = torch.nn.Conv2d(block_in,
                                        2*z_channels if double_z else z_channels,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)

    def forward(self, x):
        # timestep embedding
        temb = None

        # downsampling
        hs = [self.conv_in(x)]
        for i_level in range(self.num_resolutions):
            for i_block in range(self.num_res_blocks):
                h = self.down[i_level].block[i_block](hs[-1], temb)
                if len(self.down[i_level].attn) > 0:
                    h = self.down[i_level].attn[i_block](h)
                hs.append(h)
            if i_level != self.num_resolutions-1:
                hs.append(self.down[i_level].downsample(hs[-1]))

        # middle
        h = hs[-1]
        h = self.mid.block_1(h, temb)
        h = self.mid.attn_1(h)
        h = self.mid.block_2(h, temb)

        # end
        h = self.norm_out(h)
        h = nonlinearity(h)
        h = self.conv_out(h)
        return h


class Decoder(nn.Module):
    def __init__(self, *, ch, out_ch, ch_mult=(1,2,4,8), num_res_blocks,
                 attn_resolutions, dropout=0.0, resamp_with_conv=True, in_channels,
                 resolution, z_channels, give_pre_end=False, tanh_out=False, use_linear_attn=False,
                 attn_type="vanilla", **ignorekwargs):
        super().__init__()
        if use_linear_attn: attn_type = "linear"
        self.ch = ch
        self.temb_ch = 0
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        self.resolution = resolution
        self.in_channels = in_channels
        self.give_pre_end = give_pre_end
        self.tanh_out = tanh_out

        # compute in_ch_mult, block_in and curr_res at lowest res
        in_ch_mult = (1,)+tuple(ch_mult)
        block_in = ch*ch_mult[self.num_resolutions-1]
        curr_res = resolution // 2**(self.num_resolutions-1)
        self.z_shape = (1,z_channels,curr_res,curr_res)
        # print("Working with z of shape {} = {} dimensions.".format(
        #     self.z_shape, np.prod(self.z_shape)))

        # z to block_in
        self.conv_in = torch.nn.Conv2d(z_channels,
                                       block_in,
                                       kernel_size=3,
                                       stride=1,
                                       padding=1)

        # middle
        self.mid = nn.Module()
        self.mid.block_1 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)
        self.mid.attn_1 = make_attn(block_in, attn_type=attn_type)
        self.mid.block_2 = ResnetBlock(in_channels=block_in,
                                       out_channels=block_in,
                                       temb_channels=self.temb_ch,
                                       dropout=dropout)

        # upsampling
        self.up = nn.ModuleList()
        for i_level in reversed(range(self.num_resolutions)):
            block = nn.ModuleList()
            attn = nn.ModuleList()
            block_out = ch*ch_mult[i_level]
            for i_block in range(self.num_res_blocks+1):
                block.append(ResnetBlock(in_channels=block_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
                if curr_res in attn_resolutions:
                    attn.append(make_attn(block_in, attn_type=attn_type))
            up = nn.Module()
            up.block = block
            up.attn = attn
            if i_level != 0:
                up.upsample = Upsample(block_in, resamp_with_conv)
                curr_res = curr_res * 2
            self.up.insert(0, up) # prepend to get consistent order

        # end
        if not self.give_pre_end:
            self.norm_out = Normalize(block_in)
            self.conv_out = torch.nn.Conv2d(block_in,
                                            out_ch,
                                            kernel_size=3,
                                            stride=1,
                                            padding=1)

    def forward(self, z):
        #assert z.shape[1:] == self.z_shape[1:]
        self.last_z_shape = z.shape

        # timestep embedding
        temb = None

        # z to block_in
        h = self.conv_in(z)

        # middle
        h = self.mid.block_1(h, temb)
        h = self.mid.attn_1(h)
        h = self.mid.block_2(h, temb)

        # upsampling
        for i_level in reversed(range(self.num_resolutions)):
            for i_block in range(self.num_res_blocks+1):
                h = self.up[i_level].block[i_block](h, temb)
                if len(self.up[i_level].attn) > 0:
                    h = self.up[i_level].attn[i_block](h)
            if i_level != 0:
                h = self.up[i_level].upsample(h)

        # end
        if self.give_pre_end:
            return h

        h = self.norm_out(h)
        h = nonlinearity(h)
        h = self.conv_out(h)
        if self.tanh_out:
            h = torch.tanh(h)
        return h


@register('simple_renderer_net')
class SimpleRendererNet(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels=3, kernel_size=3, normalize=True, *args, **kwargs):
        super().__init__()
        self.model = nn.ModuleList([nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=(kernel_size - 1) // 2),
                                    ResnetBlock(in_channels=hidden_channels,
                                                out_channels=hidden_channels,
                                                kernel_size=kernel_size,
                                                temb_channels=0, dropout=0.0, normalize=normalize),
                                    ResnetBlock(in_channels=hidden_channels,
                                                out_channels=hidden_channels,
                                                kernel_size=kernel_size,
                                                temb_channels=0, dropout=0.0, normalize=normalize)])
        self.norm_out = Normalize(hidden_channels) if normalize else torch.nn.Identity()
        self.conv_out = torch.nn.Conv2d(hidden_channels, out_channels, kernel_size, padding=(kernel_size - 1) // 2)

    def get_last_layer_weight(self):
        return self.conv_out.weight

    def forward(self, x):
        for i, layer in enumerate(self.model):
            if i in [1, 2]:
                x = layer(x, None)
            else:
                x = layer(x)

        h = self.norm_out(x)
        h = nonlinearity(h)
        x = self.conv_out(h)
        return x


@register('vqgan_last_conv')
class VQGANLastConv(nn.Module):
    def __init__(self, in_channels, out_channels=3):
        super().__init__()
        self.norm_out = Normalize(in_channels)
        self.conv_out = torch.nn.Conv2d(in_channels,
                                        out_channels,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)

    def get_last_layer_weight(self):
        return self.conv_out.weight

    def forward(self, x):
        x = self.norm_out(x)
        x = nonlinearity(x)
        x = self.conv_out(x)
        return x


class SimpleDecoder(nn.Module):
    def __init__(self, in_channels, out_channels, *args, **kwargs):
        super().__init__()
        self.model = nn.ModuleList([nn.Conv2d(in_channels, in_channels, 1),
                                     ResnetBlock(in_channels=in_channels,
                                                 out_channels=2 * in_channels,
                                                 temb_channels=0, dropout=0.0),
                                     ResnetBlock(in_channels=2 * in_channels,
                                                out_channels=4 * in_channels,
                                                temb_channels=0, dropout=0.0),
                                     ResnetBlock(in_channels=4 * in_channels,
                                                out_channels=2 * in_channels,
                                                temb_channels=0, dropout=0.0),
                                     nn.Conv2d(2*in_channels, in_channels, 1),
                                     Upsample(in_channels, with_conv=True)])
        # end
        self.norm_out = Normalize(in_channels)
        self.conv_out = torch.nn.Conv2d(in_channels,
                                        out_channels,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)

    def forward(self, x):
        for i, layer in enumerate(self.model):
            if i in [1,2,3]:
                x = layer(x, None)
            else:
                x = layer(x)

        h = self.norm_out(x)
        h = nonlinearity(h)
        x = self.conv_out(h)
        return x


class UpsampleDecoder(nn.Module):
    def __init__(self, in_channels, out_channels, ch, num_res_blocks, resolution,
                 ch_mult=(2,2), dropout=0.0):
        super().__init__()
        # upsampling
        self.temb_ch = 0
        self.num_resolutions = len(ch_mult)
        self.num_res_blocks = num_res_blocks
        block_in = in_channels
        curr_res = resolution // 2 ** (self.num_resolutions - 1)
        self.res_blocks = nn.ModuleList()
        self.upsample_blocks = nn.ModuleList()
        for i_level in range(self.num_resolutions):
            res_block = []
            block_out = ch * ch_mult[i_level]
            for i_block in range(self.num_res_blocks + 1):
                res_block.append(ResnetBlock(in_channels=block_in,
                                         out_channels=block_out,
                                         temb_channels=self.temb_ch,
                                         dropout=dropout))
                block_in = block_out
            self.res_blocks.append(nn.ModuleList(res_block))
            if i_level != self.num_resolutions - 1:
                self.upsample_blocks.append(Upsample(block_in, True))
                curr_res = curr_res * 2

        # end
        self.norm_out = Normalize(block_in)
        self.conv_out = torch.nn.Conv2d(block_in,
                                        out_channels,
                                        kernel_size=3,
                                        stride=1,
                                        padding=1)

    def forward(self, x):
        # upsampling
        h = x
        for k, i_level in enumerate(range(self.num_resolutions)):
            for i_block in range(self.num_res_blocks + 1):
                h = self.res_blocks[i_level][i_block](h, None)
            if i_level != self.num_resolutions - 1:
                h = self.upsample_blocks[k](h)
        h = self.norm_out(h)
        h = nonlinearity(h)
        h = self.conv_out(h)
        return h


class LatentRescaler(nn.Module):
    def __init__(self, factor, in_channels, mid_channels, out_channels, depth=2):
        super().__init__()
        # residual block, interpolate, residual block
        self.factor = factor
        self.conv_in = nn.Conv2d(in_channels,
                                 mid_channels,
                                 kernel_size=3,
                                 stride=1,
                                 padding=1)
        self.res_block1 = nn.ModuleList([ResnetBlock(in_channels=mid_channels,
                                                     out_channels=mid_channels,
                                                     temb_channels=0,
                                                     dropout=0.0) for _ in range(depth)])
        self.attn = AttnBlock(mid_channels)
        self.res_block2 = nn.ModuleList([ResnetBlock(in_channels=mid_channels,
                                                     out_channels=mid_channels,
                                                     temb_channels=0,
                                                     dropout=0.0) for _ in range(depth)])

        self.conv_out = nn.Conv2d(mid_channels,
                                  out_channels,
                                  kernel_size=1,
                                  )

    def forward(self, x):
        x = self.conv_in(x)
        for block in self.res_block1:
            x = block(x, None)
        x = torch.nn.functional.interpolate(x, size=(int(round(x.shape[2]*self.factor)), int(round(x.shape[3]*self.factor))))
        x = self.attn(x)
        for block in self.res_block2:
            x = block(x, None)
        x = self.conv_out(x)
        return x


class MergedRescaleEncoder(nn.Module):
    def __init__(self, in_channels, ch, resolution, out_ch, num_res_blocks,
                 attn_resolutions, dropout=0.0, resamp_with_conv=True,
                 ch_mult=(1,2,4,8), rescale_factor=1.0, rescale_module_depth=1):
        super().__init__()
        intermediate_chn = ch * ch_mult[-1]
        self.encoder = Encoder(in_channels=in_channels, num_res_blocks=num_res_blocks, ch=ch, ch_mult=ch_mult,
                               z_channels=intermediate_chn, double_z=False, resolution=resolution,
                               attn_resolutions=attn_resolutions, dropout=dropout, resamp_with_conv=resamp_with_conv,
                               out_ch=None)
        self.rescaler = LatentRescaler(factor=rescale_factor, in_channels=intermediate_chn,
                                       mid_channels=intermediate_chn, out_channels=out_ch, depth=rescale_module_depth)

    def forward(self, x):
        x = self.encoder(x)
        x = self.rescaler(x)
        return x


class MergedRescaleDecoder(nn.Module):
    def __init__(self, z_channels, out_ch, resolution, num_res_blocks, attn_resolutions, ch, ch_mult=(1,2,4,8),
                 dropout=0.0, resamp_with_conv=True, rescale_factor=1.0, rescale_module_depth=1):
        super().__init__()
        tmp_chn = z_channels*ch_mult[-1]
        self.decoder = Decoder(out_ch=out_ch, z_channels=tmp_chn, attn_resolutions=attn_resolutions, dropout=dropout,
                               resamp_with_conv=resamp_with_conv, in_channels=None, num_res_blocks=num_res_blocks,
                               ch_mult=ch_mult, resolution=resolution, ch=ch)
        self.rescaler = LatentRescaler(factor=rescale_factor, in_channels=z_channels, mid_channels=tmp_chn,
                                       out_channels=tmp_chn, depth=rescale_module_depth)

    def forward(self, x):
        x = self.rescaler(x)
        x = self.decoder(x)
        return x


class Upsampler(nn.Module):
    def __init__(self, in_size, out_size, in_channels, out_channels, ch_mult=2):
        super().__init__()
        assert out_size >= in_size
        num_blocks = int(np.log2(out_size//in_size))+1
        factor_up = 1.+ (out_size % in_size)
        print(f"Building {self.__class__.__name__} with in_size: {in_size} --> out_size {out_size} and factor {factor_up}")
        self.rescaler = LatentRescaler(factor=factor_up, in_channels=in_channels, mid_channels=2*in_channels,
                                       out_channels=in_channels)
        self.decoder = Decoder(out_ch=out_channels, resolution=out_size, z_channels=in_channels, num_res_blocks=2,
                               attn_resolutions=[], in_channels=None, ch=in_channels,
                               ch_mult=[ch_mult for _ in range(num_blocks)])

    def forward(self, x):
        x = self.rescaler(x)
        x = self.decoder(x)
        return x


class Resize(nn.Module):
    def __init__(self, in_channels=None, learned=False, mode="bilinear"):
        super().__init__()
        self.with_conv = learned
        self.mode = mode
        if self.with_conv:
            print(f"Note: {self.__class__.__name} uses learned downsampling and will ignore the fixed {mode} mode")
            raise NotImplementedError()
            assert in_channels is not None
            # no asymmetric padding in torch conv, must do it ourselves
            self.conv = torch.nn.Conv2d(in_channels,
                                        in_channels,
                                        kernel_size=4,
                                        stride=2,
                                        padding=1)

    def forward(self, x, scale_factor=1.0):
        if scale_factor==1.0:
            return x
        else:
            x = torch.nn.functional.interpolate(x, mode=self.mode, align_corners=False, scale_factor=scale_factor)
        return x
'''

_DITO_RENDERER_SOURCE = r'''# https://gist.github.com/mrsteyk/74ad3ec2f6f823111ae4c90e168505ac

import torch
import torch.nn.functional as F
import torch.nn as nn

from upstream_registry import register


class TimestepEmbedding(nn.Module):
    def __init__(self, n_time=1024, n_emb=320, n_out=1280) -> None:
        super().__init__()
        self.emb = nn.Embedding(n_time, n_emb)
        self.f_1 = nn.Linear(n_emb, n_out)
        self.f_2 = nn.Linear(n_out, n_out)

    def forward(self, x) -> torch.Tensor:
        x = self.emb(x)
        x = self.f_1(x)
        x = F.silu(x)
        return self.f_2(x)


class PositionalEmbedding(nn.Module):
    def __init__(self, pe_dim=320, out_dim=1280, max_positions=10000, endpoint=True):
        super().__init__()
        self.num_channels = pe_dim
        self.max_positions = max_positions
        self.endpoint = endpoint
        self.f_1 = nn.Linear(pe_dim, out_dim)
        self.f_2 = nn.Linear(out_dim, out_dim)

    def forward(self, x):
        freqs = torch.arange(start=0, end=self.num_channels//2, dtype=torch.float32, device=x.device)
        freqs = freqs / (self.num_channels // 2 - (1 if self.endpoint else 0))
        freqs = (1 / self.max_positions) ** freqs
        x = x.ger(freqs.to(x.dtype))
        x = torch.cat([x.cos(), x.sin()], dim=1)
        
        x = self.f_1(x)
        x = F.silu(x)
        return self.f_2(x)


class ImageEmbedding(nn.Module):
    def __init__(self, in_channels, out_channels=320) -> None:
        super().__init__()
        self.f = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)

    def forward(self, x) -> torch.Tensor:
        return self.f(x)


class ImageUnembedding(nn.Module):
    def __init__(self, in_channels=320, out_channels=3) -> None:
        super().__init__()
        self.gn = nn.GroupNorm(32, in_channels)
        self.f = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)

    def forward(self, x) -> torch.Tensor:
        return self.f(F.silu(self.gn(x)))


class ConvResblock(nn.Module):
    def __init__(self, in_features, out_features, t_dim) -> None:
        super().__init__()
        self.f_t = nn.Linear(t_dim, out_features * 2)

        self.gn_1 = nn.GroupNorm(32, in_features)
        self.f_1 = nn.Conv2d(in_features, out_features, kernel_size=3, padding=1)

        self.gn_2 = nn.GroupNorm(32, out_features)
        self.f_2 = nn.Conv2d(out_features, out_features, kernel_size=3, padding=1)

        skip_conv = in_features != out_features
        self.f_s = (
            nn.Conv2d(in_features, out_features, kernel_size=1, padding=0)
            if skip_conv
            else nn.Identity()
        )

    def forward(self, x, t):
        x_skip = x
        t = self.f_t(F.silu(t))
        t = t.chunk(2, dim=1)
        t_1 = t[0].unsqueeze(dim=2).unsqueeze(dim=3) + 1
        t_2 = t[1].unsqueeze(dim=2).unsqueeze(dim=3)

        gn_1 = F.silu(self.gn_1(x))
        f_1 = self.f_1(gn_1)

        gn_2 = self.gn_2(f_1)

        return self.f_s(x_skip) + self.f_2(F.silu(gn_2 * t_1 + t_2))


# Also ConvResblock
class Downsample(nn.Module):
    def __init__(self, in_channels, t_dim) -> None:
        super().__init__()
        self.f_t = nn.Linear(t_dim, in_channels * 2)

        self.gn_1 = nn.GroupNorm(32, in_channels)
        self.f_1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.gn_2 = nn.GroupNorm(32, in_channels)

        self.f_2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)

    def forward(self, x, t) -> torch.Tensor:
        x_skip = x

        t = self.f_t(F.silu(t))
        t_1, t_2 = t.chunk(2, dim=1)
        t_1 = t_1.unsqueeze(2).unsqueeze(3) + 1
        t_2 = t_2.unsqueeze(2).unsqueeze(3)

        gn_1 = F.silu(self.gn_1(x))
        avg_pool2d = F.avg_pool2d(gn_1, kernel_size=(2, 2), stride=None)
        f_1 = self.f_1(avg_pool2d)
        gn_2 = self.gn_2(f_1)

        f_2 = self.f_2(F.silu(t_2 + (t_1 * gn_2)))

        return f_2 + F.avg_pool2d(x_skip, kernel_size=(2, 2), stride=None)


# Also ConvResblock
class Upsample(nn.Module):
    def __init__(self, in_channels, t_dim) -> None:
        super().__init__()
        self.f_t = nn.Linear(t_dim, in_channels * 2)

        self.gn_1 = nn.GroupNorm(32, in_channels)
        self.f_1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.gn_2 = nn.GroupNorm(32, in_channels)

        self.f_2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)

    def forward(self, x, t) -> torch.Tensor:
        x_skip = x

        t = self.f_t(F.silu(t))
        t_1, t_2 = t.chunk(2, dim=1)
        t_1 = t_1.unsqueeze(2).unsqueeze(3) + 1
        t_2 = t_2.unsqueeze(2).unsqueeze(3)

        gn_1 = F.silu(self.gn_1(x))
        upsample = F.interpolate(gn_1, scale_factor=2, mode="nearest")
        f_1 = self.f_1(upsample)
        gn_2 = self.gn_2(f_1)

        f_2 = self.f_2(F.silu(t_2 + (t_1 * gn_2)))

        return f_2 + F.interpolate(x_skip, scale_factor=2, mode="nearest")


@register('consistency_decoder_unet')
class ConsistencyDecoderUNet(nn.Module):
    def __init__(self, in_channels=3, z_dec_channels=None, c0=320, c1=640, c2=1024, pe_dim=320, t_dim=1280) -> None:
        super().__init__()
        if z_dec_channels is not None:
            in_channels += z_dec_channels
        self.embed_image = ImageEmbedding(in_channels=in_channels, out_channels=c0)
        self.embed_time = PositionalEmbedding(pe_dim=pe_dim, out_dim=t_dim)

        down_0 = nn.ModuleList([
            ConvResblock(c0, c0, t_dim),
            ConvResblock(c0, c0, t_dim),
            ConvResblock(c0, c0, t_dim),
            Downsample(c0, t_dim),
        ])
        down_1 = nn.ModuleList([
            ConvResblock(c0, c1, t_dim),
            ConvResblock(c1, c1, t_dim),
            ConvResblock(c1, c1, t_dim),
            Downsample(c1, t_dim),
        ])
        down_2 = nn.ModuleList([
            ConvResblock(c1, c2, t_dim),
            ConvResblock(c2, c2, t_dim),
            ConvResblock(c2, c2, t_dim),
            Downsample(c2, t_dim),
        ])
        down_3 = nn.ModuleList([
            ConvResblock(c2, c2, t_dim),
            ConvResblock(c2, c2, t_dim),
            ConvResblock(c2, c2, t_dim),
        ])
        self.down = nn.ModuleList([
            down_0,
            down_1,
            down_2,
            down_3,
        ])

        self.mid = nn.ModuleList([
            ConvResblock(c2, c2, t_dim),
            ConvResblock(c2, c2, t_dim),
        ])

        up_3 = nn.ModuleList([
            ConvResblock(c2 * 2, c2, t_dim),
            ConvResblock(c2 * 2, c2, t_dim),
            ConvResblock(c2 * 2, c2, t_dim),
            ConvResblock(c2 * 2, c2, t_dim),
            Upsample(c2, t_dim),
        ])
        up_2 = nn.ModuleList([
            ConvResblock(c2 * 2, c2, t_dim),
            ConvResblock(c2 * 2, c2, t_dim),
            ConvResblock(c2 * 2, c2, t_dim),
            ConvResblock(c2 + c1, c2, t_dim),
            Upsample(c2, t_dim),
        ])
        up_1 = nn.ModuleList([
            ConvResblock(c2 + c1, c1, t_dim),
            ConvResblock(c1 * 2, c1, t_dim),
            ConvResblock(c1 * 2, c1, t_dim),
            ConvResblock(c0 + c1, c1, t_dim),
            Upsample(c1, t_dim),
        ])
        up_0 = nn.ModuleList([
            ConvResblock(c0 + c1, c0, t_dim),
            ConvResblock(c0 * 2, c0, t_dim),
            ConvResblock(c0 * 2, c0, t_dim),
            ConvResblock(c0 * 2, c0, t_dim),
        ])
        self.up = nn.ModuleList([
            up_0,
            up_1,
            up_2,
            up_3,
        ])

        self.output = ImageUnembedding(in_channels=c0, out_channels=1)  # Adaptación LEGO: alfa, no RGB
    
    def get_last_layer_weight(self):
        return self.output.f.weight

    def forward(self, x, t=None, z_dec=None) -> torch.Tensor:
        if z_dec is not None:
            if z_dec.shape[-2] != x.shape[-2] or z_dec.shape[-1] != x.shape[-1]:
                assert x.shape[-2] // z_dec.shape[-2] == x.shape[-1] // z_dec.shape[-1]
                z_dec = F.interpolate(z_dec, scale_factor=x.shape[-2] // z_dec.shape[-2], mode="nearest")
            x = torch.cat([x, z_dec], dim=1)
        
        x = self.embed_image(x)

        if t is None:
            t = torch.zeros(x.shape[0], device=x.device)        
        t = self.embed_time(t)

        skips = [x]
        for down in self.down:
            for block in down:
                x = block(x, t)
                skips.append(x)

        for mid in self.mid:
            x = mid(x, t)

        for up in self.up[::-1]:
            for block in up:
                if isinstance(block, ConvResblock):
                    x = torch.concat([x, skips.pop()], dim=1)
                x = block(x, t)

        return self.output(x)
'''

_DITO_FM_SOURCE = r'''import torch

from upstream_registry import register


@register('fm')
class FM:
    
    def __init__(self, sigma_min=1e-5, timescale=1.0):
        self.sigma_min = sigma_min
        self.prediction_type = None
        self.timescale = timescale
    
    def alpha(self, t):
        return 1.0 - t
    
    def sigma(self, t):
        return self.sigma_min + t * (1.0 - self.sigma_min)
    
    def A(self, t):
        return 1.0
    
    def B(self, t):
        return -(1.0 - self.sigma_min)
    
    def get_betas(self, n_timesteps):
        return torch.zeros(n_timesteps) # Not VP and not supported
    
    def add_noise(self, x, t, noise=None):
        noise = torch.randn_like(x) if noise is None else noise
        s = [x.shape[0]] + [1] * (x.dim() - 1)
        x_t = self.alpha(t).view(*s) * x + self.sigma(t).view(*s) * noise
        return x_t, noise
    
    def loss(self, net, x, t=None, net_kwargs=None, return_loss_unreduced=False, return_all=False):
        if net_kwargs is None:
            net_kwargs = {}
        
        if t is None:
            t = torch.rand(x.shape[0], device=x.device)
        x_t, noise = self.add_noise(x, t)
        
        pred = net(x_t, t=t * self.timescale, **net_kwargs)
        
        target = self.A(t) * x + self.B(t) * noise # -dxt/dt
        if return_loss_unreduced:
            loss = ((pred.float() - target.float()) ** 2).mean(dim=[1, 2, 3])
            if return_all:
                return loss, t, x_t, pred
            else:
                return loss, t
        else:
            loss = ((pred.float() - target.float()) ** 2).mean()
            if return_all:
                return loss, x_t, pred
            else:
                return loss
    
    def get_prediction(
        self,
        net,
        x_t,
        t,
        net_kwargs=None,
        uncond_net_kwargs=None,
        guidance=1.0,
    ):
        if net_kwargs is None:
            net_kwargs = {}
        pred = net(x_t, t=t * self.timescale, **net_kwargs)
        if guidance != 1.0:
            assert uncond_net_kwargs is not None
            uncond_pred = net(x_t, t=t * self.timescale, **uncond_net_kwargs)
            pred = uncond_pred + guidance * (pred - uncond_pred)
        return pred
    
    def convert_sample_prediction(self, x_t, t, pred):
        M = torch.tensor([
            [self.alpha(t), self.sigma(t)],
            [self.A(t), self.B(t)],
        ], dtype=torch.float64)
        M_inv = torch.linalg.inv(M)
        sample_pred = M_inv[0, 0].item() * x_t + M_inv[0, 1].item() * pred
        return sample_pred
'''

_DITO_SAMPLER_SOURCE = r'''import numpy as np
import torch

from upstream_registry import register


@register('fm_euler_sampler')
class FMEulerSampler:

    def __init__(self, diffusion):
        self.diffusion = diffusion

    def sample(
        self,
        net,
        shape,
        n_steps,
        net_kwargs=None,
        uncond_net_kwargs=None,
        guidance=1.0,
        noise=None,
    ):
        device = next(net.parameters()).device
        x_t = torch.randn(shape, device=device) if noise is None else noise
        t_steps = torch.linspace(1, 0, n_steps + 1, device=device)

        with torch.no_grad():
            for i in range(n_steps):
                t = t_steps[i].repeat(x_t.shape[0])
                neg_v = self.diffusion.get_prediction(
                    net,
                    x_t,
                    t,
                    net_kwargs=net_kwargs,
                    uncond_net_kwargs=uncond_net_kwargs,
                    guidance=guidance,
                )
                x_t = x_t + neg_v * (t_steps[i] - t_steps[i + 1])
        return x_t
'''

_FLOW1_SOURCE = r'''def rope_2d(dim_cabeza, lado=16):
    d = dim_cabeza // 4
    frec = 1.0 / (10000 ** (torch.arange(d) / d))
    y, x = torch.meshgrid(torch.arange(lado), torch.arange(lado), indexing="ij")
    ang = torch.cat([y.flatten()[:, None] * frec, x.flatten()[:, None] * frec], 1)   # 256 × dim/2
    return torch.cos(ang), torch.sin(ang)

def aplicar_rope(x, cos, sin):                              # x: B×H×N×D
    x1, x2 = x[..., 0::2], x[..., 1::2]
    return torch.stack([x1 * cos - x2 * sin, x1 * sin + x2 * cos], -1).flatten(-2)

class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.peso, self.eps = nn.Parameter(torch.ones(d)), eps

    def forward(self, x):
        return x * torch.rsqrt(x.float().pow(2).mean(-1, keepdim=True) + self.eps).to(x.dtype) * self.peso.to(x.dtype)

class Atencion(nn.Module):
    def __init__(self, dim, cabezas, cruzada=False):
        super().__init__()
        self.h, self.cruzada = cabezas, cruzada
        self.q = nn.Linear(dim, dim)
        self.kv = nn.Linear(dim, 2 * dim)
        self.nq, self.nk = RMSNorm(dim // cabezas), RMSNorm(dim // cabezas)
        self.salida = nn.Sequential(nn.Linear(dim, dim), nn.Dropout(CONFIG["DROPOUT"]))

    def forward(self, x, contexto=None, rope=None):
        b, n, d = x.shape
        c = x if contexto is None else contexto
        q = self.q(x).view(b, n, self.h, -1).transpose(1, 2)
        k, v = self.kv(c).view(b, c.shape[1], 2, self.h, -1).permute(2, 0, 3, 1, 4)
        q, k = self.nq(q), self.nk(k)
        if rope is not None:
            q, k = aplicar_rope(q, *rope), aplicar_rope(k, *rope)
        y = F.scaled_dot_product_attention(q, k, v)
        return self.salida(y.transpose(1, 2).reshape(b, n, d))

def modular(x, shift, scale):
    return x * (1 + scale[:, None]) + shift[:, None]

class Bloque(nn.Module):
    def __init__(self, dim, cabezas, mlp):
        super().__init__()
        self.n1, self.n2, self.n3 = (nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6) for _ in range(3))
        self.auto = Atencion(dim, cabezas)
        self.cruzada = Atencion(dim, cabezas, cruzada=True)
        self.mlp = nn.Sequential(nn.Linear(dim, int(dim * mlp)), nn.GELU(approximate="tanh"),
                                 nn.Dropout(CONFIG["DROPOUT"]), nn.Linear(int(dim * mlp), dim))
        self.ada = nn.Sequential(nn.SiLU(), nn.Linear(dim, 9 * dim))
        nn.init.zeros_(self.ada[1].weight)
        nn.init.zeros_(self.ada[1].bias)

    def forward(self, x, c, foto, rope):
        s1, e1, g1, s2, e2, g2, s3, e3, g3 = self.ada(c).chunk(9, dim=1)
        x = x + g1[:, None] * self.auto(modular(self.n1(x), s1, e1), rope=rope)
        x = x + g2[:, None] * self.cruzada(modular(self.n2(x), s2, e2), contexto=foto)
        return x + g3[:, None] * self.mlp(modular(self.n3(x), s3, e3))

def embedding_tiempo(t, dim):
    mitad = dim // 2
    frec = torch.exp(-math.log(10000) * torch.arange(mitad, device=t.device) / mitad)
    a = t[:, None] * 1000 * frec[None]
    return torch.cat([torch.cos(a), torch.sin(a)], 1)

class DiT1(nn.Module):
    def __init__(self, dim=CONFIG["DIM"], prof=CONFIG["PROFUNDIDAD"], cabezas=CONFIG["CABEZAS"],
                 mlp=CONFIG["MLP"], dim_dino=768, n_tok=256):
        super().__init__()
        self.dim = dim
        self.entrada = nn.Linear(8, dim)
        self.pos = nn.Parameter(torch.zeros(1, n_tok, dim))
        self.tiempo = nn.Sequential(nn.Linear(dim, dim), nn.SiLU(), nn.Linear(dim, dim))
        self.proyeccion = nn.Sequential(nn.LayerNorm(dim_dino), nn.Linear(dim_dino, dim))
        self.sin_foto = nn.Parameter(torch.zeros(1, 1, dim))         # token "nulo" para CFG
        self.bloques = nn.ModuleList(Bloque(dim, cabezas, mlp) for _ in range(prof))
        self.n_final = nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6)
        self.ada_final = nn.Sequential(nn.SiLU(), nn.Linear(dim, 2 * dim))
        self.salida = nn.Linear(dim, 8)
        for m in [self.ada_final[1], self.salida]:
            nn.init.zeros_(m.weight)
            nn.init.zeros_(m.bias)
        nn.init.normal_(self.pos, std=0.02)
        nn.init.normal_(self.sin_foto, std=0.02)
        self.register_buffer("rope_cos", rope_2d(dim // cabezas)[0], persistent=False)
        self.register_buffer("rope_sin", rope_2d(dim // cabezas)[1], persistent=False)

    def forward(self, x_t, t, tok_foto, sin_foto=None):
        """x_t: B×256×8 · t: B · tok_foto: B×N×768 · sin_foto: B bool (True = omitir la foto)."""
        foto = self.proyeccion(tok_foto)
        if sin_foto is not None:
            foto = torch.where(sin_foto[:, None, None], self.sin_foto.expand_as(foto), foto)
        c = self.tiempo(embedding_tiempo(t, self.dim))
        x = self.entrada(x_t) + self.pos
        rope = (self.rope_cos, self.rope_sin)
        for b in self.bloques:
            x = b(x, c, foto, rope)
        shift, scale = self.ada_final(c).chunk(2, dim=1)
        return self.salida(modular(self.n_final(x), shift, scale))'''

_FLOW1_GENERATE_SOURCE = r'''def generate(model,photo,seeds,w=1.,steps=None,method='euler'):
 model.eval()
 if CONFIG['MODO']=='regresor':return model(photo).float()
 steps=steps or CONFIG['PASOS_FLOW']
 x=torch.stack([torch.randn((256,8),generator=torch.Generator().manual_seed(int(s))) for s in seeds]).to(DEVICE)
 def vel(x,t):
  times=torch.full((len(x),),float(t),device=DEVICE)
  with amp_ctx():
   vc=model(x,times,photo,torch.zeros(len(x),dtype=torch.bool,device=DEVICE)).float()
   if w==1:return vc
   vu=model(x,times,photo,torch.ones(len(x),dtype=torch.bool,device=DEVICE)).float()
  return vu+w*(vc-vu)
 for i in range(steps):
  t=i/steps;v=vel(x,t)
  if method=='heun':x=x+(v+vel(x+v/steps,(i+1)/steps))/(2*steps)
  else:x=x+v/steps
 return x'''

_FLOW2_SOURCE = r'''def rope_2d(dim_cabeza, lado=16):
    d = dim_cabeza // 4
    frec = 1.0 / (10000 ** (torch.arange(d) / d))
    y, x = torch.meshgrid(torch.arange(lado), torch.arange(lado), indexing="ij")
    ang = torch.cat([y.flatten()[:, None] * frec, x.flatten()[:, None] * frec], 1)   # 256 × dim/2
    return torch.cos(ang), torch.sin(ang)

def aplicar_rope(x, cos, sin):                              # x: B×H×N×D
    x1, x2 = x[..., 0::2], x[..., 1::2]
    return torch.stack([x1 * cos - x2 * sin, x1 * sin + x2 * cos], -1).flatten(-2)

class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.peso, self.eps = nn.Parameter(torch.ones(d)), eps

    def forward(self, x):
        return x * torch.rsqrt(x.float().pow(2).mean(-1, keepdim=True) + self.eps).to(x.dtype) * self.peso.to(x.dtype)

def modular(x, shift, scale):
    return x * (1 + scale[:, None]) + shift[:, None]

def embedding_tiempo(t, dim):
    mitad = dim // 2
    frec = torch.exp(-math.log(10000) * torch.arange(mitad, device=t.device) / mitad)
    a = t[:, None] * 1000 * frec[None]
    return torch.cat([torch.cos(a), torch.sin(a)], 1)

class Attention2(nn.Module):
 def __init__(self,dim,heads,dropout):
  super().__init__();self.heads=heads
  self.q=nn.Linear(dim,dim);self.kv=nn.Linear(dim,2*dim)
  self.nq=RMSNorm(dim//heads);self.nk=RMSNorm(dim//heads)
  self.out=nn.Sequential(nn.Linear(dim,dim),nn.Dropout(dropout))
 def forward(self,x,context=None,rope=None):
  b,n,d=x.shape;c=x if context is None else context
  q=self.q(x).reshape(b,n,self.heads,-1).transpose(1,2)
  k,v=self.kv(c).reshape(b,len(c[0]),2,self.heads,-1).permute(2,0,3,1,4)
  q,k=self.nq(q),self.nk(k)
  if rope is not None:q,k=aplicar_rope(q,*rope),aplicar_rope(k,*rope)
  y=F.scaled_dot_product_attention(q,k,v)
  return self.out(y.transpose(1,2).reshape(b,n,d))
class CrossBlock(nn.Module):
 def __init__(self,d,heads,ratio,drop):
  super().__init__();self.norms=nn.ModuleList([nn.LayerNorm(d,elementwise_affine=False) for _ in range(3)])
  self.selfatt=Attention2(d,heads,drop);self.cross=Attention2(d,heads,drop)
  self.mlp=nn.Sequential(nn.Linear(d,int(d*ratio)),nn.GELU(approximate='tanh'),nn.Dropout(drop),nn.Linear(int(d*ratio),d))
  self.ada=nn.Sequential(nn.SiLU(),nn.Linear(d,9*d));nn.init.zeros_(self.ada[-1].weight);nn.init.zeros_(self.ada[-1].bias)
 def forward(self,x,time,photo,rope):
  s1,e1,g1,s2,e2,g2,s3,e3,g3=self.ada(time).chunk(9,1)
  x=x+g1[:,None]*self.selfatt(modular(self.norms[0](x),s1,e1),rope=rope)
  x=x+g2[:,None]*self.cross(modular(self.norms[1](x),s2,e2),context=photo)
  return x+g3[:,None]*self.mlp(modular(self.norms[2](x),s3,e3))
class SingleBlock(nn.Module):
 def __init__(self,d,heads,ratio,drop):
  super().__init__();self.n1=nn.LayerNorm(d,elementwise_affine=False);self.n2=nn.LayerNorm(d,elementwise_affine=False)
  self.att=Attention2(d,heads,drop)
  self.mlp=nn.Sequential(nn.Linear(d,int(d*ratio)),nn.GELU(approximate='tanh'),nn.Dropout(drop),nn.Linear(int(d*ratio),d))
  self.ada=nn.Sequential(nn.SiLU(),nn.Linear(d,6*d));nn.init.zeros_(self.ada[-1].weight);nn.init.zeros_(self.ada[-1].bias)
 def forward(self,x,time,rope):
  s1,e1,g1,s2,e2,g2=self.ada(time).chunk(6,1)
  x=x+g1[:,None]*self.att(modular(self.n1(x),s1,e1),rope=rope)
  return x+g2[:,None]*self.mlp(modular(self.n2(x),s2,e2))
class PhotoColor(nn.Module):
 def __init__(self,grid):
  super().__init__();self.grid=grid
  self.net=nn.Sequential(nn.Conv2d(3,32,5,2,2),nn.SiLU(),nn.Conv2d(32,64,3,2,1),nn.SiLU(),nn.Conv2d(64,96,3,2,1),nn.SiLU())
 def forward(self,rgb):
  x=F.interpolate(rgb,size=(128,128),mode='bilinear',align_corners=False)
  f=F.adaptive_avg_pool2d(self.net(x),self.grid)
  mean=F.adaptive_avg_pool2d(x,self.grid)
  std=(F.adaptive_avg_pool2d(x*x,self.grid)-mean.square()).clamp_min(1e-6).sqrt()
  h=torch.cat([f,mean,std],1).flatten(2).transpose(1,2)
  return torch.cat([h.mean(1,keepdim=True),h],1)
class Flow2DiT(nn.Module):
 def __init__(self,arch,cfg,dino_dim):
  super().__init__();self.arch=arch;self.cfg=dict(cfg);d=cfg['DIM'];self.dim=d
  self.mask_encoder=nn.Sequential(nn.Conv2d(1,32,3,2,1),nn.SiLU(),nn.Conv2d(32,32,3,2,1),nn.SiLU(),nn.Conv2d(32,32,3,2,1),nn.SiLU())
  self.color=PhotoColor(cfg['DINO_POOL']);self.dino_proj=nn.Sequential(nn.LayerNorm(dino_dim),nn.Linear(dino_dim,d))
  self.rgb_proj=nn.Linear(102,d);self.null=nn.Parameter(torch.zeros(1,1,d))
  self.time=nn.Sequential(nn.Linear(d,d),nn.SiLU(),nn.Linear(d,d))
  self.pos=nn.Parameter(torch.randn(1,256,d)*.02);self.types=nn.Parameter(torch.randn(3,d)*.02)
  self.input=nn.Linear(41 if arch=='cross' else 8,d)
  self.mask_proj=nn.Linear(33,d)
  if arch=='cross':self.blocks=nn.ModuleList([CrossBlock(d,cfg['CABEZAS'],cfg['MLP'],cfg['DROPOUT']) for _ in range(cfg['PROF_CROSS'])])
  elif arch=='single':self.blocks=nn.ModuleList([SingleBlock(d,cfg['CABEZAS'],cfg['MLP'],cfg['DROPOUT']) for _ in range(cfg['PROF_SINGLE'])])
  else:raise ValueError(arch)
  self.final_norm=nn.LayerNorm(d,elementwise_affine=False);self.final_ada=nn.Sequential(nn.SiLU(),nn.Linear(d,2*d));self.out=nn.Linear(d,8)
  for layer in [self.final_ada[-1],self.out]:nn.init.zeros_(layer.weight);nn.init.zeros_(layer.bias)
  cos,sin=rope_2d(d//cfg['CABEZAS']);self.register_buffer('cos',cos,persistent=False);self.register_buffer('sin',sin,persistent=False)
 def forward(self,xt,t,dino,rgb,mask,drop=None):
  occ=(F.adaptive_max_pool2d(mask,16)>.5).float().flatten(2).transpose(1,2)
  shape=self.mask_encoder(mask).flatten(2).transpose(1,2)
  shape=torch.cat([shape,occ],-1)
  photo=self.dino_proj(dino)+self.rgb_proj(self.color(rgb))
  if drop is not None:photo=torch.where(drop[:,None,None],self.null.expand_as(photo),photo)
  time=self.time(embedding_tiempo(t,self.dim))
  if self.arch=='cross':
   x=self.input(torch.cat([xt,shape],-1))+self.pos
   for block in self.blocks:x=block(x,time,photo,(self.cos,self.sin))
  else:
   noisy=self.input(xt)+self.pos+self.types[0]
   shapes=self.mask_proj(shape)+self.pos+self.types[1]
   x=torch.cat([noisy,shapes,photo+self.types[2]],1)
   n=photo.shape[1]
   cos=torch.cat([self.cos,self.cos,torch.ones(n,self.cos.shape[1],device=xt.device)],0)
   sin=torch.cat([self.sin,self.sin,torch.zeros(n,self.sin.shape[1],device=xt.device)],0)
   for block in self.blocks:x=block(x,time,(cos,sin))
   x=x[:,:256]
  shift,scale=self.final_ada(time).chunk(2,1)
  return self.out(modular(self.final_norm(x),shift,scale))*occ
'''

_FLOW2_GENERATE_SOURCE = r'''def generate2(model,h,rgb,m,seeds,w=1.,steps=None,method='euler'):
 model.eval();steps=steps or CONFIG['PASOS_FLOW'];a=to_tokens(active(m))
 x=torch.stack([torch.randn((256,8),generator=torch.Generator().manual_seed(int(s))) for s in seeds]).to(DEVICE)*a
 def vel(x,t):
  tt=torch.full((len(x),),float(t),device=DEVICE)
  with amp_ctx():
   v=model(x,tt,h,rgb,m,torch.zeros(len(x),dtype=torch.bool,device=DEVICE)).float()
   if w!=1:
    u=model(x,tt,h,rgb,m,torch.ones(len(x),dtype=torch.bool,device=DEVICE)).float();v=u+w*(v-u)
  return v
 for j in range(steps):
  v=vel(x,j/steps)
  x=x+(v+vel(x+v/steps,(j+1)/steps))/(2*steps) if method=='heun' else x+v/steps
  x=x*a
 if not torch.isfinite(x).all():raise FloatingPointError('Latente generado no finito')
 return x'''


# ---- Construcción de las arquitecturas exactas, sin ejecutar notebooks ----

def _modulo(nombre: str, fuente: str, **extra: Any) -> ModuleType:
    module = ModuleType(__name__ + "." + nombre)
    module.__dict__.update(torch=torch, nn=nn, F=F, math=math, np=np,
                           register=lambda name: lambda cls: cls)
    module.__dict__.update(extra)
    # El registro de entrenamiento no interviene en inferencia.
    fuente = fuente.replace("from upstream_registry import register", "")
    exec(compile(fuente, "<lego_face:" + nombre + ">", "exec"), module.__dict__)
    return module


@lru_cache(maxsize=1)
def _dito_modules():
    codec = _modulo("dito_codec", _DITO_ENCODER_SOURCE)
    renderer = _modulo("dito_renderer", _DITO_RENDERER_SOURCE)
    fm = _modulo("dito_fm", _DITO_FM_SOURCE).FM(sigma_min=1e-5, timescale=1000.)
    sampler = _modulo("dito_sampler", _DITO_SAMPLER_SOURCE).FMEulerSampler(fm)
    return codec, renderer, sampler


class DiToMascara(nn.Module):
    """Codec geométrico de vae1.pt. Es DiTo, con encoder determinista."""
    kind = "dito_base"
    is_vae = False

    def __init__(self):
        super().__init__()
        codec, renderer, sampler = _dito_modules()
        self.encoder = codec.Encoder(ch=32, out_ch=1, ch_mult=(1,2,4,4),
            num_res_blocks=1, attn_resolutions=(), dropout=0., in_channels=1,
            resolution=128, z_channels=8, double_z=False)
        self.norm = nn.LayerNorm((8,16,16), elementwise_affine=False)
        self.decoder = renderer.ConsistencyDecoderUNet(in_channels=1,
            z_dec_channels=8, c0=32, c1=64, c2=128, pe_dim=64, t_dim=128)
        self._sampler = sampler

    def encode(self, mask):
        return self.norm(self.encoder(mask * 2 - 1))

    def forward(self, x, t, z_dec):
        return self.decoder(x, t=t, z_dec=z_dec)

    @torch.no_grad()
    def decode(self, z, seeds: Sequence[int] | None = None, steps=32):
        if seeds is None:
            seeds = list(range(len(z)))
        if len(seeds) != len(z) or int(steps) < 1:
            raise ValueError("Una semilla por latente y steps >= 1")
        noise = torch.stack([torch.randn((1,128,128),
            generator=torch.Generator().manual_seed(int(seed))) for seed in seeds]).to(z.device)
        y = self._sampler.sample(self, (len(z),1,128,128), int(steps),
                                net_kwargs={"z_dec": z}, noise=noise)
        return ((y + 1) / 2).clamp(0,1)


@dataclass
class ModeloCargado:
    modelo: nn.Module
    metadatos: dict[str, Any]
    sha256: str
    origen: str


def _device(device="auto"):
    device = str(device)
    if device == "auto":
        device = "cuda:0" if torch.cuda.is_available() else "cpu"
    d = torch.device(device)
    if d.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Se pidió CUDA y no está disponible. Usa device='cpu'.")
    return d


def _checkpoint(origen, nombre):
    """Acepta el .pt individual, Face/ o Face.zip; no exige rutas de Kaggle."""
    path = Path(origen).expanduser()
    if path.is_file():
        with open(path,"rb") as stream:
            if stream.read(128).startswith(b"version https://git-lfs.github.com/spec/"):
                raise ValueError(f"{path} es un puntero Git LFS. Ejecuta git lfs pull para descargar los pesos.")
    if path.is_file() and path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as archive:
            matches = [n for n in archive.namelist()
                       if not n.endswith("/") and Path(n).name == nombre]
            if len(matches) != 1:
                raise ValueError(f"Se esperaba un solo {nombre} dentro de {path}: {matches}")
            data = archive.read(matches[0])
        source = f"{path}!/{matches[0]}"
    else:
        if path.is_dir():
            exact = path / nombre
            matches = [exact] if exact.is_file() else list(path.rglob(nombre))
            if len(matches) != 1:
                raise ValueError(f"Se esperaba un solo {nombre} en {path}: {matches}")
            path = matches[0]
        if not path.is_file():
            raise FileNotFoundError(f"No se encontró el checkpoint: {path}")
        data = path.read_bytes()
        if data.startswith(b"version https://git-lfs.github.com/spec/"):
            raise ValueError(f"{path} es un puntero Git LFS. Ejecuta git lfs pull para descargar los pesos.")
        source = str(path)
    # Los cuatro checkpoints proporcionados se cargan con el lector restringido.
    ck = torch.load(io.BytesIO(data), map_location="cpu", weights_only=True)
    if not isinstance(ck, dict) or not isinstance(ck.get("ema"), dict):
        raise ValueError(f"{source}: falta el diccionario de pesos EMA")
    return ck, hashlib.sha256(data).hexdigest(), source


def _loaded(model, ck, sha, source, device):
    model.load_state_dict(ck["ema"], strict=True)
    model.to(_device(device)).eval().requires_grad_(False)
    # No conservar una segunda copia de todos los pesos ni del código upstream.
    metadata = {k:v for k,v in ck.items() if k not in ["ema", "upstream"]}
    return ModeloCargado(model, metadata, sha, source)


def cargar_vae1(origen, device="auto"):
    """Carga vae1.pt: encoder y decoder DiTo de máscaras."""
    ck, sha, source = _checkpoint(origen, "vae1.pt")
    if ck.get("kind") != "dito_base":
        raise ValueError("vae1.pt debe ser el codec de máscaras kind='dito_base'.")
    return _loaded(DiToMascara(), ck, sha, source, device)


def cargar_flow1(origen, device="auto"):
    """Carga flow1.pt. No descarga DINO ni necesita la VAE para cargar pesos."""
    ck, sha, source = _checkpoint(origen, "flow1.pt")
    cfg = dict(ck.get("config", {}))
    if cfg.get("MODO") != "flow" or "stats" not in ck or "tokenizer_sha" not in ck:
        raise ValueError("Se esperaba el export final del Flow 1 DiT con stats y tokenizer_sha.")
    if "upstream" in ck:
        expected = {"codec.py": _DITO_ENCODER_SOURCE, "renderer.py": _DITO_RENDERER_SOURCE,
                    "fm.py": _DITO_FM_SOURCE, "samplers.py": _DITO_SAMPLER_SOURCE}
        for name, text in expected.items():
            if ck["upstream"].get(name) != text:
                raise ValueError(f"La fuente DiTo {name} difiere de la versión incluida.")
    module = _modulo("flow1", _FLOW1_SOURCE, CONFIG=cfg)
    dim_dino = int(ck["ema"]["proyeccion.1.weight"].shape[1])
    model = module.DiT1(dim=cfg["DIM"], prof=cfg["PROFUNDIDAD"],
                        cabezas=cfg["CABEZAS"], mlp=cfg["MLP"], dim_dino=dim_dino)
    return _loaded(model, ck, sha, source, device)


def cargar_vae2(origen, device="auto"):
    """Carga vae2.pt: VAE de color y estadísticas para su espacio latente."""
    ck, sha, source = _checkpoint(origen, "vae2.pt")
    if ck.get("kind") != "vae_control" or ck.get("artifact_role") != "lego_color_codec":
        raise ValueError("vae2.pt debe ser el export de color kind='vae_control'.")
    cfg = ck["config"]
    return _loaded(VAEColor(cfg["Z_CHANNELS"], tuple(cfg["CANALES"])),
                   ck, sha, source, device)


def cargar_flow2(origen, device="auto"):
    """Carga flow2.pt: arquitectura cross o single indicada por el checkpoint."""
    ck, sha, source = _checkpoint(origen, "flow2.pt")
    if ck.get("artifact_role") != "flow2_color" or ck.get("smoke", False):
        raise ValueError("Se esperaba el export real del Flow 2 de color.")
    module = _modulo("flow2", _FLOW2_SOURCE)
    return _loaded(module.Flow2DiT(ck["arch"], ck["config"], ck["dino_dim"]),
                   ck, sha, source, device)


def _tokens(z):
    return z.flatten(2).transpose(1,2)


def _grid(z):
    if z.ndim == 3 and z.shape[1:] == (256,8):
        return z.transpose(1,2).reshape(len(z),8,16,16)
    if z.ndim == 4 and z.shape[1:] == (8,16,16):
        return z
    raise ValueError("Latente esperado: B×256×8 o B×8×16×16")


def _active(mask):
    return (F.adaptive_max_pool2d(mask,16) > .5).float()


def _rgb_array(source):
    if isinstance(source, (str, Path)):
        with Image.open(source) as im:
            return np.asarray(im.convert("RGB")).copy()
    if isinstance(source, Image.Image):
        return np.asarray(source.convert("RGB")).copy()
    a = np.asarray(source)
    if a.ndim != 3 or a.shape[2] != 3:
        raise ValueError("Foto esperada RGB H×W×3; si usas OpenCV convierte BGR a RGB.")
    if a.dtype != np.uint8:
        raise ValueError("Los arrays de foto deben ser uint8 en [0,255].")
    return a.copy()


def _canonical_mask(source):
    if isinstance(source, (str, Path)):
        with Image.open(source) as im:
            a = np.asarray(im.getchannel("A") if "A" in im.getbands() else im.convert("L")).copy()
    elif isinstance(source, Image.Image):
        a = np.asarray(source.getchannel("A") if "A" in source.getbands() else source.convert("L")).copy()
    else:
        a = np.asarray(source)
        if a.ndim == 3 and a.shape[-1] == 4:
            a = a[:,:,3]
        if a.ndim == 3 and a.shape[0] == 1:
            a = a[0]
    if a.ndim != 2 or not np.isfinite(a).all():
        raise ValueError("Máscara esperada H×W, binaria, con valores finitos.")
    h,w = a.shape
    if h > 128 or w > 128 or h < 1 or w < 1:
        raise ValueError("La máscara debe caber en 128×128. Se centra; no se deforma ni redimensiona.")
    threshold = 127 if float(a.max()) > 1 else .5
    m = np.zeros((128,128), np.float32)
    y,x = (128-h)//2,(128-w)//2
    m[y:y+h,x:x+w] = (a > threshold).astype(np.float32)
    if not 0 < float(m.mean()) < 1:
        raise ValueError("Máscara vacía o completa. Revisa la salida de Flow 1.")
    return m


def _canonical_rgba(source):
    if isinstance(source, (str, Path)):
        with Image.open(source) as im:
            if "A" not in im.getbands() and "transparency" not in im.info:
                raise ValueError("La estampa debe tener alfa.")
            a = np.asarray(im.convert("RGBA")).copy()
    elif isinstance(source, Image.Image):
        if "A" not in source.getbands():
            raise ValueError("La estampa debe tener alfa.")
        a = np.asarray(source.convert("RGBA")).copy()
    else:
        a = np.asarray(source)
    if a.dtype != np.uint8 or a.ndim != 3 or a.shape[2] != 4:
        raise ValueError("Estampa esperada RGBA uint8 H×W×4")
    h,w = a.shape[:2]
    if h > 128 or w > 128:
        raise ValueError("La estampa debe caber en 128×128; no se redimensiona.")
    out = np.zeros((128,128,4), np.uint8)
    y,x = (128-h)//2,(128-w)//2
    m = a[:,:,3] >= 128
    out[y:y+h,x:x+w,:3] = a[:,:,:3] * m[:,:,None]
    out[y:y+h,x:x+w,3] = m.astype(np.uint8)*255
    _canonical_mask(out[:,:,3])
    return out


class ModelosCara:
    """Los cuatro modelos y la cascada foto→máscara→RGBA, sin entrenamiento."""

    def __init__(self, origen, device="auto", dino_local=None, solo_local=False, usar_amp=None):
        self.device = _device(device)
        self.usar_amp = self.device.type == "cuda" if usar_amp is None else bool(usar_amp)
        if self.usar_amp and self.device.type != "cuda":
            raise ValueError("AMP float16 está habilitado solo para CUDA en este módulo.")
        self.cargados = {
            "vae1": cargar_vae1(origen, self.device), "flow1": cargar_flow1(origen, self.device),
            "vae2": cargar_vae2(origen, self.device), "flow2": cargar_flow2(origen, self.device),
        }
        self.vae1 = self.cargados["vae1"].modelo
        self.flow1 = self.cargados["flow1"].modelo
        self.vae2 = self.cargados["vae2"].modelo
        self.flow2 = self.cargados["flow2"].modelo
        self.meta = {k:v.metadatos for k,v in self.cargados.items()}
        self.cfg1, self.cfg2 = self.meta["flow1"]["config"], self.meta["flow2"]["config"]
        if self.meta["flow1"]["tokenizer_sha"] != self.cargados["vae1"].sha256:
            raise ValueError("vae1.pt no es el DiTo exacto que utilizó Flow 1 (SHA-256 distinto).")
        if self.meta["flow1"]["dino"] != self.cfg2["DINO"]:
            raise ValueError("Flow 1 y Flow 2 requieren extractores DINO distintos.")
        if self.meta["flow2"]["dino_dim"] != self.flow1.proyeccion[1].in_features:
            raise ValueError("Dimensión DINO incompatible entre los flows.")
        stats1,stats2 = self.meta["flow1"]["stats"],self.meta["vae2"]["stats"]
        def channel_stats(st,key):
            v = torch.as_tensor(st[key],dtype=torch.float32,device=self.device).reshape(1,8,1,1)
            if not torch.isfinite(v).all() or (key == "desv" and (v <= 0).any()):
                raise ValueError("Estadísticas latentes inválidas: " + key)
            return v
        self.media1,self.desv1 = channel_stats(stats1,"media"),channel_stats(stats1,"desv")
        self.media2,self.desv2 = channel_stats(stats2,"media"),channel_stats(stats2,"desv").clamp_min(1e-6)
        proc = self.meta["flow1"].get("processor",{})
        self.image_mean = torch.tensor(proc.get("image_mean",[.485,.456,.406]),device=self.device)[None,:,None,None]
        self.image_std = torch.tensor(proc.get("image_std",[.229,.224,.225]),device=self.device)[None,:,None,None]
        self._sample1 = _modulo("sample_flow1", _FLOW1_GENERATE_SOURCE,
            CONFIG=self.cfg1, DEVICE=self.device, amp_ctx=self._amp).generate
        self._sample2 = _modulo("sample_flow2", _FLOW2_GENERATE_SOURCE,
            CONFIG=self.cfg2, DEVICE=self.device, amp_ctx=self._amp,
            active=_active, to_tokens=_tokens).generate2
        self._dino = None
        self.dino_local, self.solo_local = dino_local, bool(solo_local)
        self._detector = None

    def _amp(self):
        return torch.autocast("cuda",dtype=torch.float16) if self.usar_amp else nullcontext()

    def resumen(self):
        return {name:dict(origen=item.origen,sha256=item.sha256,
            parametros=sum(p.numel() for p in item.modelo.parameters()),
            tensores=len(item.modelo.state_dict()),version=item.metadatos.get("config",{}).get("VERSION"),
            kind=item.metadatos.get("kind"),arch=item.metadatos.get("arch"),
            cfg=item.metadatos.get("cfg_w")) for name,item in self.cargados.items()}

    def cargar_dino(self):
        if self._dino is None:
            from transformers import AutoModel
            source = str(self.dino_local) if self.dino_local is not None else self.meta["flow1"]["dino"]
            self._dino = AutoModel.from_pretrained(source,local_files_only=self.solo_local)
            if int(self._dino.config.hidden_size) != int(self.meta["flow2"]["dino_dim"]):
                self._dino = None
                raise ValueError("El DINO proporcionado no tiene la dimensión que requieren los pesos.")
            self._dino.to(self.device).eval().requires_grad_(False)
        return self._dino

    def preparar_foto(self, foto, recortar=True):
        a = _rgb_array(foto)
        detected = False
        if recortar:
            import cv2
            if not hasattr(cv2,"CascadeClassifier"):
                raise ImportError("El recorte requiere OpenCV 4: pip install 'opencv-python-headless>=4.10,<5'")
            if self._detector is None:
                self._detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
                if self._detector.empty():
                    raise RuntimeError("No se encontró el detector Haar de OpenCV.")
            h,w = a.shape[:2]
            faces = self._detector.detectMultiScale(cv2.cvtColor(a,cv2.COLOR_RGB2GRAY),1.1,5,
                                                   minSize=(max(16,w//6),)*2)
            detected = bool(len(faces))
            if detected:
                x,y,cw,ch = max(faces,key=lambda q:q[2]*q[3])
                cx,cy,s = x+cw/2,y+ch/2,max(cw,ch)*1.8
            else:
                cx,cy,s = w/2,h*.45,min(w,h)*.75
            x0,y0 = max(0,int(cx-s/2)),max(0,int(cy-s/2))
            x1,y1 = min(w,int(cx+s/2)),min(h,int(cy+s/2))
            a = a[y0:y1,x0:x1]
        if not a.size:
            raise ValueError("El recorte de la foto quedó vacío.")
        return np.asarray(Image.fromarray(a).resize((256,256),Image.Resampling.BICUBIC)).copy(),detected

    @torch.inference_mode()
    def extraer_condiciones(self, foto, recortar=True):
        a,detected = self.preparar_foto(foto,recortar)
        rgb = torch.from_numpy(a.copy()).permute(2,0,1)[None].to(self.device).float()/255
        x = F.interpolate(rgb,(self.cfg1['LADO_FOTO'],)*2,mode='bilinear',align_corners=False,antialias=True)
        with self._amp():
            full = self.cargar_dino()(pixel_values=(x-self.image_mean)/self.image_std).last_hidden_state.float()
        side = math.isqrt(full.shape[1]-1)
        if side*side != full.shape[1]-1:
            raise ValueError("Tokens DINO inesperados: se esperaba CLS + cuadrícula cuadrada.")
        pooled = F.adaptive_avg_pool2d(full[:,1:].transpose(1,2).reshape(1,-1,side,side),self.cfg2['DINO_POOL'])
        pooled = torch.cat([full[:,:1],pooled.flatten(2).transpose(1,2)],1)
        return dict(foto=a,rgb=rgb,dino_completo=full,dino_color=pooled,cara_detectada=detected)

    @torch.inference_mode()
    def codificar_mascara(self, mascara, estandarizado=False):
        m = torch.from_numpy(_canonical_mask(mascara))[None,None].to(self.device)
        with self._amp():z = self.vae1.encode(m).float()
        return _tokens((z-self.media1)/self.desv1) if estandarizado else z

    @torch.inference_mode()
    def decodificar_mascara(self, z, seed=42, pasos=None, estandarizado=False):
        z = _grid(torch.as_tensor(z,dtype=torch.float32,device=self.device))
        if estandarizado:z = z*self.desv1+self.media1
        with self._amp():
            y = self.vae1.decode(z,[int(seed)+i for i in range(len(z))],
                steps=int(pasos or self.cfg1.get('PASOS_DITO_FINAL',32))).float()
        return y

    @torch.inference_mode()
    def codificar_color(self, rgba, estandarizado=False):
        a = _canonical_rgba(rgba)
        c = torch.from_numpy(a.copy()).permute(2,0,1)[None].to(self.device).float()/255
        m = c[:,3:4]
        with self._amp():z = self.vae2.encode(c[:,:3],m).float()
        return _tokens(((z-self.media2)/self.desv2)*_active(m)) if estandarizado else z

    @torch.inference_mode()
    def decodificar_color(self, z, mascara, estandarizado=False):
        m = torch.from_numpy(_canonical_mask(mascara))[None,None].to(self.device)
        z = _grid(torch.as_tensor(z,dtype=torch.float32,device=self.device))
        if len(z) != 1:raise ValueError("Este método recibe una máscara y un código; usa vae2 directamente para lotes.")
        if estandarizado:z = (z*self.desv2+self.media2)*_active(m)
        with self._amp():y = self.vae2.decodificar(z,m).float()
        return y

    @torch.inference_mode()
    def generar(self, foto, mascara=None, seed=42, recortar=True,
                pasos_flow1=None,pasos_dito=None,pasos_flow2=None,
                cfg_flow1=None,cfg_flow2=None,metodo='euler'):
        """Foto RGB→RGBA. Máscara opcional para usar solamente la etapa de color.

        foto: ruta/PIL/array RGB uint8. mascara: H×W, 0/1 o 0/255, máximo 128×128.
        Devuelve RGBA uint8 128×128×4 con fondo transparente, y latentes de diagnóstico.
        """
        if metodo not in ['euler','heun']:
            raise ValueError("metodo debe ser euler o heun")
        c = self.extraer_condiciones(foto,recortar)
        seed = int(seed)
        w1 = float(self.meta['flow1']['cfg_w'] if cfg_flow1 is None else cfg_flow1)
        w2 = float(self.meta['flow2']['cfg_w'] if cfg_flow2 is None else cfg_flow2)
        z1 = prob = None
        if mascara is None:
            z1 = self._sample1(self.flow1,c['dino_completo'],[seed],w=w1,
                steps=int(pasos_flow1 or self.cfg1['PASOS_FLOW']),method=metodo)
            raw = _grid(z1)*self.desv1+self.media1
            with self._amp():
                prob = self.vae1.decode(raw,[seed],steps=int(pasos_dito or self.cfg1.get('PASOS_DITO_FINAL',32))).float()
            m = (prob >= .5).float()
            if not 0 < float(m.mean()) < 1:
                raise ValueError("Flow 1 produjo máscara vacía/completa; prueba otra semilla o revisa su predicción.")
        else:
            m = torch.from_numpy(_canonical_mask(mascara))[None,None].to(self.device)
        z2 = self._sample2(self.flow2,c['dino_color'],c['rgb'],m,[seed],w=w2,
            steps=int(pasos_flow2 or self.cfg2['PASOS_FLOW']),method=metodo)
        raw2 = (_grid(z2)*self.desv2+self.media2)*_active(m)
        with self._amp():y = self.vae2.decodificar(raw2,m).float()
        if not torch.isfinite(y).all():raise FloatingPointError("RGB no finito")
        rgb = y[0].permute(1,2,0).cpu().numpy()
        mask = m[0,0].cpu().numpy()
        rgba = np.concatenate([(rgb*255).round().clip(0,255).astype(np.uint8),
                               (mask[:,:,None]*255).astype(np.uint8)],2)
        return dict(rgba=rgba,rgb=rgb,mascara=(mask*255).astype(np.uint8),foto=c['foto'],
            probabilidad=None if prob is None else prob[0,0].cpu().numpy(),
            latente_mascara_estandarizado=None if z1 is None else z1.cpu(),
            latente_color_estandarizado=z2.cpu(),latente_color=raw2.cpu(),
            cara_detectada=c['cara_detectada'],seed=seed,cfg_flow1=w1,cfg_flow2=w2)


def cargar_modelos(origen, device='auto', dino_local=None, solo_local=False, usar_amp=None):
    """Carga Face.zip o la carpeta con flow1.pt, flow2.pt, vae1.pt y vae2.pt."""
    return ModelosCara(origen,device=device,dino_local=dino_local,solo_local=solo_local,usar_amp=usar_amp)


def main():
    parser = argparse.ArgumentParser(description='Inferencia local de los cuatro modelos LEGO Face')
    parser.add_argument('--params',required=True,help='Face.zip o carpeta Face')
    parser.add_argument('--foto',help='Foto humana para generar RGBA')
    parser.add_argument('--mascara',help='Máscara opcional: usar solo la generación de color')
    parser.add_argument('--salida',default='lego.png')
    parser.add_argument('--device',default='auto')
    parser.add_argument('--dino-local',default=None,help='Carpeta save_pretrained de DINOv2-base')
    parser.add_argument('--solo-local',action='store_true')
    parser.add_argument('--sin-recorte',action='store_true',help='La foto ya está recortada')
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--threads',type=int,default=4)
    args = parser.parse_args()
    if args.threads > 0:torch.set_num_threads(args.threads)
    model = cargar_modelos(args.params,device=args.device,dino_local=args.dino_local,solo_local=args.solo_local)
    print(json.dumps(model.resumen(),ensure_ascii=False,indent=2))
    if args.foto:
        result = model.generar(args.foto,mascara=args.mascara,seed=args.seed,recortar=not args.sin_recorte)
        target = Path(args.salida);target.parent.mkdir(parents=True,exist_ok=True)
        Image.fromarray(result['rgba']).save(target)
        print('Guardado:',target)


if __name__ == '__main__':
    main()
