"""Ejemplo: python ejemplo_local.py --params Face.zip --foto persona.jpg"""
import argparse
from pathlib import Path
from PIL import Image
from lego_face import cargar_modelos


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--params', required=True)
    parser.add_argument('--foto', required=True)
    parser.add_argument('--salida', default='resultado_lego')
    parser.add_argument('--device', default='auto')
    parser.add_argument('--dino-local')
    parser.add_argument('--solo-local', action='store_true')
    args = parser.parse_args()
    modelos = cargar_modelos(args.params, device=args.device,
                             dino_local=args.dino_local, solo_local=args.solo_local)
    resultado = modelos.generar(args.foto, seed=42)
    carpeta = Path(args.salida)
    carpeta.mkdir(parents=True, exist_ok=True)
    Image.fromarray(resultado['rgba']).save(carpeta / 'lego_rgba.png')
    Image.fromarray(resultado['mascara']).save(carpeta / 'mascara.png')
    Image.fromarray(resultado['foto']).save(carpeta / 'foto_recortada.png')
    print('Resultado guardado en:', carpeta.resolve())


if __name__ == '__main__':
    main()
