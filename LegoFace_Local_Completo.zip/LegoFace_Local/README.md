# LEGO Face · los cuatro modelos en Python local

`lego_face.py` contiene las arquitecturas, los cargadores, los samplers y el procesamiento necesario para usar los cuatro archivos de `Face.zip`. No ejecuta notebooks, no necesita Kaggle ni los CSV/datasets de entrenamiento.

## 1. Qué es cada archivo de Face.zip

| Peso proporcionado | Modelo real | Entrada y salida | Notebook que corresponde |
|---|---|---|---|
| `Face/vae1.pt` | **DiTo base de máscaras**, no una VAE probabilística | Encoder: máscara 1×128×128 → código 8×16×16. Decoder: código + ruido → máscara | La arquitectura exacta está incluida en `ptd-flow1-2 (3).ipynb`, celda «Codec exacto y procedencia». No está adjunto el notebook original que entrenó `lego_geometria/runs/dito_base/best.pt`. |
| `Face/flow1.pt` | **Flow 1 DiT**, versión `f1e_cargado` | Tokens DINO de una foto + ruido → código de máscara estandarizado | `ptd-flow1-2 (3).ipynb` y `(4)`; ambos tienen el mismo código. |
| `Face/vae2.pt` | **VAE de color**, `vae_control`, versión `color_v2` | Encoder: RGB LEGO + máscara → media latente. Decoder: código + máscara → RGB | `ptd-vae2-2.ipynb` y `ptd-lego-caras-vae2_actualizado(1).ipynb`; tienen el mismo código. |
| `Face/flow2.pt` | **Flow 2 cross**, versión `flow2_v1_20k` | Foto + máscara + ruido → código de color estandarizado | Arquitectura en `ptd-flow2.ipynb` / `Flow2_Color_LEGO_Completo(1).ipynb`. Continuación que produjo esta versión: `Flow2_Color_Continuacion_20k(1).ipynb`. |

Todos se cargan desde `ema` con `strict=True`, sin ignorar claves ni usar pesos aleatorios como sustitución. En los archivos adjuntos: Flow 1 usa CFG **2.0**, Flow 2 usa CFG **1.5**. El loader lee esos valores del checkpoint.

El SHA-256 de `vae1.pt` coincide con `tokenizer_sha` de `flow1.pt`. Renombrarlo a `vae1.pt` no alteró sus bytes y la comprobación pasa. Flow 2 no contiene un hash explícito de la VAE de color; la validación de esa pareja comprueba su tipo, arquitectura, dimensiones y estadísticas disponibles, y se ha probado la inferencia con estos cuatro archivos exactos.

**No falta código ni otro peso propio para la inferencia de estos cuatro modelos.** Si quieres archivar también el historial de entrenamiento de la geometría, faltaría el notebook que produjo `lego_geometria` y comparó `vae_control`, `dito_base` y `dito_sync`. Su ausencia no bloquea este módulo, porque Flow 1 incluye las fuentes exactas de DiTo.

## 2. Duplicados y versiones que conviene separar

- `ptd-flow1-2 (3).ipynb` y `(4)`: mismo código del reentrenamiento Flow1Works. Las diferencias de archivo no representan otra arquitectura.
- `flow1_dito_completo_kaggle(1).ipynb` y `ptd-flow1-2 (5).ipynb`: mismo código `f1d_dito`, anterior al reentrenamiento `f1e_cargado`; el segundo contiene resultados ejecutados.
- `ptd-legoface-flow1(1).ipynb`: versión antigua `f1c` de foto → máscara, basada en un codec anterior. No utilizarla para interpretar la arquitectura de `vae1.pt` ni para cargar este Flow 1 final.
- `ptd-vae2-2.ipynb` y `ptd-lego-caras-vae2_actualizado(1).ipynb`: mismo código `color_v2`, que comparó VAE y DiTo de color.
- `ptd-lego-caras-vae2 (2).ipynb`: VAE de color antigua `c1`; no es la fuente elegida para estos pesos.
- `ptd-flow2.ipynb`, `Flow2_Color_LEGO_Completo(1).ipynb` y `Flow2_Color_LEGO_Completo (1).ipynb`: mismo código base de Flow 2; cambian los resultados/metadatos guardados.
- `Flow2_Color_Continuacion_20k(1).ipynb`: extensión de la ganadora, correspondiente a `flow2.pt` recibido.
- `Flow2_Color_Continuacion_100k(1).ipynb`: extensión posterior preparada. **Los pesos que recibimos no son de 100k:** su configuración indica `flow2_v1_20k`.
- `ptd-interlegos (1).ipynb`: genera estampas LEGO intermedias con FLUX.2 klein; es producción de datos.
- `ptd-generatesynfromsyn (2).ipynb`: genera personas para las estampas intermedias; también es producción de datos.

Los grupos se identificaron comparando el contenido de las celdas de código, no solo los nombres. El inventario completo está en `inventario_notebooks.json`.

## 3. Instalación

Python 3.10 o posterior. En una terminal situada en esta carpeta:

```powershell
python -m pip install -r requirements.txt
```

Para elegir una compilación concreta de PyTorch para tu GPU, instala primero la que corresponda y después el resto de requisitos. El módulo acepta `device="cpu"`, `device="cuda:0"` o `device="auto"`.

La prueba incluida se ejecutó en Linux, Python 3.12 y CPU con PyTorch 2.15.0+cpu. Las versiones probadas están en `pruebas/resultado_pruebas.json`. No se ejecutó una prueba de CUDA ni de Windows en esta máquina.

## 4. Cargar todos los parámetros

Puedes dejar `Face.zip` tal cual, sin descomprimirlo:

```python
from lego_face import cargar_modelos

modelos = cargar_modelos(
    r"C:\Users\USER\Documents\LegoParams\Face.zip",
    device="auto",
)
print(modelos.resumen())
```

También acepta la carpeta descomprimida que contiene los cuatro `.pt`:

```python
modelos = cargar_modelos(r"C:\Users\USER\Documents\LegoParams\Face")
```

Esto carga `modelos.vae1`, `modelos.flow1`, `modelos.vae2` y `modelos.flow2`. Son módulos PyTorch en modo `eval`, con parámetros congelados. No descarga DINO hasta que necesites procesar una foto.

Para verificar solo la carga desde terminal:

```powershell
python lego_face.py --params "C:\Users\USER\Documents\LegoParams\Face.zip" --device cpu
```

## 5. Generar desde una foto humana

```python
from PIL import Image
from lego_face import cargar_modelos

modelos = cargar_modelos(r"C:\Users\USER\Documents\LegoParams\Face.zip")
resultado = modelos.generar(r"C:\fotos\persona.jpg", seed=42)
Image.fromarray(resultado["rgba"]).save("lego.png")
Image.fromarray(resultado["mascara"]).save("mascara.png")
```

El recorrido es foto → recorte Haar de 256×256 → DINO → Flow 1 → decoder DiTo → máscara → Flow 2 → decoder VAE de color → RGBA 128×128. La piel/fondo queda transparente: el amarillo de las figuras es un fondo de visualización, no un material predicho por estos modelos.

`resultado["rgba"]` es un array uint8 `128×128×4`; `resultado["rgb"]` es RGB float32 en [0,1]; `resultado["mascara"]` tiene valores 0/255. También se devuelven la foto recortada, la probabilidad de máscara y los códigos latentes con nombres que indican si están estandarizados.

Por terminal:

```powershell
python lego_face.py --params "C:\Users\USER\Documents\LegoParams\Face.zip" --foto "C:\fotos\persona.jpg" --salida "lego.png"
```

### DINOv2

`Face.zip` contiene tus cuatro modelos entrenados, pero no el extractor preentrenado `facebook/dinov2-base`. El módulo lo descarga una vez mediante Transformers y usa su cache. No sube la foto a un servicio: el procesamiento ocurre en tu máquina.

Para trabajar completamente offline, prepara la carpeta una vez en una máquina con conexión:

```python
from transformers import AutoModel
AutoModel.from_pretrained("facebook/dinov2-base").save_pretrained("dino_local")
```

Después:

```python
modelos = cargar_modelos("Face.zip", dino_local="dino_local", solo_local=True)
```

El módulo aplica la normalización del processor guardado en `flow1.pt`; no requiere un notebook ni el processor como archivo aparte. Si usas la carpeta DINO de un output completo anterior, también funciona.

## 6. Usar una máscara propia y generar solamente color

```python
resultado = modelos.generar(
    "persona.jpg",
    mascara="mi_mascara.png",
    seed=42,
)
```

La máscara debe representar las zonas impresas de la cara. Acepta valores 0/1 o 0/255. Si procede de un PNG RGBA usa el alfa. Las estampas/máscaras de 128×118 se centran en 128×128 sin redimensionarlas, como en los notebooks. Tamaños mayores y máscaras vacías/completas se rechazan.

Con máscara explícita se omite la generación de Flow 1; se conserva esa geometría y se predice el color condicionado por la foto. No se cambia automáticamente una boca ni se añade una arruga ausente de la máscara.

Para una foto que ya está recortada puedes usar `recortar=False`. Los arrays deben ser **RGB uint8**, no BGR de OpenCV.

## 7. Cargar o llamar cada modelo por separado

```python
from lego_face import cargar_vae1, cargar_flow1, cargar_vae2, cargar_flow2

geom = cargar_vae1("Face/vae1.pt", device="cpu")
f1   = cargar_flow1("Face/flow1.pt", device="cpu")
color = cargar_vae2("Face/vae2.pt", device="cpu")
f2   = cargar_flow2("Face/flow2.pt", device="cpu")

# Cada retorno contiene .modelo, .metadatos, .sha256 y .origen.
encoder_mascara = geom.modelo.encoder
decoder_mascara = geom.modelo.decoder
encoder_color = color.modelo.encoder
decoder_color = color.modelo.decoder
```

Los códigos físicos de los codecs tienen forma `B×8×16×16`. Los flows operan sobre `B×256×8` estandarizado. Para no mezclar espacios, la API conjunta ofrece:

```python
z = modelos.codificar_mascara("mi_mascara.png")              # código físico DiTo
p = modelos.decodificar_mascara(z, seed=42)                 # tensor B×1×128×128

zc = modelos.codificar_color("estampa_rgba.png")            # media física VAE
rgb = modelos.decodificar_color(zc, "mi_mascara.png")       # tensor 1×3×128×128

zs = modelos.codificar_color("estampa_rgba.png", estandarizado=True)
rgb = modelos.decodificar_color(zs, "mi_mascara.png", estandarizado=True)
```

El RGBA usado para codificar color y la máscara empleada al reconstruir deben corresponderse. Llamar al encoder VAE de color no procesa una foto humana: las fotos se utilizan como condición de los flows.

La configuración de capas, los valores de normalización y CFG se leen de los checkpoints. El código incluye Euler y Heun para los flows; el decoder DiTo conserva su sampler original y su convención temporal. Por defecto se usan 25 pasos en cada flow y 32 en el decoder de máscaras, según los exports proporcionados.

## 8. Verificación realizada con tus archivos

La carpeta `pruebas` incluye el resultado de ejecutar los cuatro modelos con los pesos reales adjuntos. Se comprobó:

- Carga estricta de los **907 tensores** y coincidencia de cada tensor con su checkpoint: DiTo 480, Flow 1 148, VAE color 114, Flow 2 165.
- Coincidencia SHA-256 del DiTo requerido por Flow 1.
- Cascada completa con DINOv2-base real, 25 pasos de cada flow y 32 del decoder DiTo.
- Paridad con el export de inferencia original del notebook: la misma máscara, RGB, código de color y RGBA en CPU.
- Ruta de color con máscara explícita, normalizaciones inversas, codificación/decodificación de ambos codecs y recorte Haar.

La foto de prueba se extrajo de una figura que ya habías aportado. Sirve para comprobar la integración; no es un nuevo test independiente de calidad ni reproduce el archivo de foto original del dataset. Los resultados de evaluación de entrenamiento no se recalcularon aquí.

`prueba_local.png` muestra foto, máscara y resultado sobre amarillo; `lego_prueba.png` conserva el fondo transparente. Los pesos de `Face.zip` y los de DINO no se duplican en este paquete de código.
